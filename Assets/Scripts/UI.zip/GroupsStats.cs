using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class GroupsStats : MonoBehaviour
{
    public static Text uiF;
    public static Text uiS;
    public Text[] textStats;
    public Button myButton;
    public static List<Group> Groups { get; private set; }
    public static int groupsCounter = 0;

    public static int peopleAmount;
    public GameObject person;
    public static GameObject personSt;

    [System.Serializable]
    public class Group
    {
        public int Id { get; set; }
        public int membersAmount { get; set; }
        public List<int> membersId { get; set; }
        public List<int> mStatus { get; set; }

        public float groupStress;
        public int mostStressed;
        public int lessStressed;
        public int notStressed;

    }

    void Awake()
    {
        uiF = textStats[0];
        uiS = textStats[1];
        personSt = person;
        Groups = new List<Group>();

        //Group newGroup = new Group { Id = groupsCounter, membersAmount = 5 };
        //  Groups.Add(new Group { Id = groupsCounter, membersAmount=5, membersId = { 0 }, mStatus = { 0 } });

        /*for (int i = 0; i < newGroup.membersAmount; i++)
        {
            newGroup.membersId.Add(0);
            newGroup.mStatus.Add(0);
        }*/
        //Groups.Add(newGroup);
        //  Groups[groupsCounter].membersId =0;
    }


    // Start is called before the first frame update
    void Start()
    {

        AddNewGroup(4);
        StartCoroutine(DoSomethingWithDelay(5));
        StartCoroutine(DoSomethingWithDelay(3));
        StartCoroutine(DoSomethingWithDelay(8));
        StartCoroutine(DoSomethingWithDelay(3));
        StartCoroutine(DoSomethingWithDelay(10));
        StartCoroutine(DoSomethingWithDelay(8));
      //  StartCoroutine(DoSomethingWithDelay(5));
        //  AddNewGroup(5);
        //  AddNewGroup(3);
        myButton = GameObject.Find("ButtonStress").GetComponent<Button>();
        if (myButton != null)
        {
            // ������������� �� ������� ������� ������
            myButton.onClick.AddListener(ButtonStress);
        }
    }

    // Update is called once per frame
    void Update()
    {

    }
    IEnumerator DoSomethingWithDelay(int i)
    {
      //  Debug.Log("Start of Coroutine");

        yield return new WaitForSeconds(1f); // ��������� 3 �������
        AddNewGroup(i);
       // Debug.Log("After waiting for 3 seconds");

        // ��� ���, ������� ������ ����������� ����� ��������
    }
    public static void AddMember(int groupid, int id, int status)
    {
        if (Groups[groupid] != null)
        {
            Groups[groupid].membersAmount++;
            Groups[groupid].membersId.Add(id);
            Groups[groupid].mStatus.Add(status);
        }
    }

    public static void AddMember(int groupid,int id, GameObject person)
    {
        if (Groups[groupid] != null) {

            if (Groups[groupid].membersId == null)
            {
                Groups[groupid].membersId = new List<int>();
            }
            Groups[groupid].membersAmount++;
            Groups[groupid].membersId.Add(id);
            if (Groups[groupid].mStatus == null)
            {
                Groups[groupid].mStatus = new List<int>();
            }

            if (Groups[groupid].membersAmount<10)
            {
                Groups[groupid].mStatus.Add(Groups[groupid].membersAmount - 1);
            }
            else {
                Groups[groupid].mStatus.Add(UnityEngine.Random.Range(9,11));
            }

            person.GetComponent<PersonalData>().Groups.Add(groupid);
           // Debug.Log(person.name);
        //    Debug.Log("Group:"+Groups[groupid].Id+" ("+Groups[groupid].membersAmount+"/"+ (peopleAmount+1) + ")  ----   id:" + Groups[groupid].membersId[Groups[groupid].membersAmount - 1] + "/" + Groups[groupid].mStatus[Groups[groupid].membersAmount - 1]);

        }
    }


    public static void DeleteMember(int groupid, int id)
    {
        if (Groups[groupid] != null)
        {
            for (int i = Groups[groupid].membersId.IndexOf(id); i < Groups[groupid].membersAmount - 1; i++) {
                Groups[groupid].membersId[i] = Groups[groupid].membersId[i + 1];
            }
            Groups[groupid].membersId.RemoveAt(Groups[groupid].membersId.Count - 1);
            Groups[groupid].membersId.RemoveAt(Groups[groupid].mStatus.Count - 1);
            Groups[groupid].membersAmount--;

            if (Groups[groupid].membersAmount < 2) {
                Groups.RemoveAt(groupid);
            }
        }
    }



    public static void ShowGroupInfo(int groupid) {
        //  Debug.Log("Group:" + (Groups[groupid].Id+1) + " (" + Groups[groupid].membersAmount + "/" + (peopleAmount + 1) + ") ");
        Text show;
        if (Groups[groupid].Id % 2 == 0) {
            show = uiF;
        }
        else{
            show = uiS;
        }
        //show.text += "Group:" + (Groups[groupid].Id + 1) + " (" + Groups[groupid].membersAmount + "/" + (peopleAmount + 1) + ") " + "\n";
        show.text += "Group:" + (Groups[groupid].Id + 1) + " (" + Groups[groupid].membersAmount + ") " + "\n";

        for (int i = 0; i < Groups[groupid].membersAmount; i++)
        {
           // Debug.Log("Group:" + Groups[groupid].Id + " (" + Groups[groupid].membersAmount + "/" + (peopleAmount + 1) + ")  ----   id:" + Groups[groupid].membersId[i] + "/" + Groups[groupid].mStatus[i]);
           // Debug.Log(Groups[groupid].mStatus[i]+ ") id " + Groups[groupid].membersId[i]);
            show.text += Groups[groupid].mStatus[i] + ") id " + Groups[groupid].membersId[i] + "\n";
            //Debug.Log(i+" "+ Groups[groupid].membersId[i]);
        }
        show.text += "~~~~~~" + "\n"; 
        
       // Debug.Log("~~~~~~");
    }



    public static void AddNewGroup()
    {
        groupsCounter++;
        int amount = UnityEngine.Random.Range(3, 11);
        Debug.Log(groupsCounter + " need:" + amount);
        Group newGroup = new Group { Id = groupsCounter-1, membersAmount = 0 };
        Groups.Add(newGroup);
        //  Groups.Add(new Group { Id = groupsCounter, membersAmount=5, membersId = { 0 }, mStatus = { 0 } });
        if (peopleAmount < amount)
        {
            for (int i = 0; i < amount; i++)
            {
                int memberNum = UnityEngine.Random.Range(0, amount);
                //  Debug.Log(GameObject.Find("Person" + memberNum));
                SearchNext(newGroup, memberNum, amount);

            }
        }
        else
        {
            for (int i = 0; i < amount; i++)
            {

                int memberNum = UnityEngine.Random.Range(0, peopleAmount);
                // Debug.Log(GameObject.Find("Person" + memberNum));
                SearchNext(newGroup, memberNum, peopleAmount);
            }
        }
    }


    public static void AddNewGroup(int amount)
    {
        groupsCounter++;
       // Debug.Log(groupsCounter+" need:"+amount);
      //  Debug.Log(groupsCounter+" need:"+amount);
        Group newGroup = new Group { Id = groupsCounter-1, membersAmount = 0 };
        Groups.Add(newGroup);
        //  Groups.Add(new Group { Id = groupsCounter, membersAmount=5, membersId = { 0 }, mStatus = { 0 } });
        if (peopleAmount < amount)
        {
            for (int i = 0; i < amount; i++)
            {
                //int memberNum = Random.Range(0, amount);
              //  Debug.Log(GameObject.Find("Person" + memberNum));
                SearchNext(newGroup, i, amount);
                
            }
        }
        else
        {
            for (int i = 0; i < amount; i++)
            {
                
                int memberNum = UnityEngine.Random.Range(0, peopleAmount);
               // Debug.Log(GameObject.Find("Person" + memberNum));
                SearchNext(newGroup, memberNum, peopleAmount);
            }
        }
        ShowGroupInfo(groupsCounter-1);
        // Groups.Add(newGroup);
    }


    public static void SearchNext(Group newGroup,int id,int amount) {

        if(id<peopleAmount)
        {
            GameObject person = (GameObject.Find("Person" + id));
            if (newGroup.membersId == null || newGroup.membersId.IndexOf(id) == -1)
            {
                AddMember(newGroup.Id, id, person);
            }
            else
            {
                id = UnityEngine.Random.Range(0, amount);
                SearchNext(newGroup, id, amount);
            }
        }
        else
        {
            if (peopleAmount < 21)
            {
                GameObject newPerson = Instantiate(personSt, new Vector3(UnityEngine.Random.Range(-24, 25), 0, UnityEngine.Random.Range(-24, 25)), Quaternion.identity);
                newPerson.GetComponent<PersonalData>().id = peopleAmount;
                newPerson.GetComponent<PersonalData>().gameObject.name = "Person" + peopleAmount;
                newPerson.GetComponent<PersonalData>().Groups = new List<int>();
                AddMember(newGroup.Id, peopleAmount, newPerson);
                peopleAmount++;
            }
            else
            {
                id = UnityEngine.Random.Range(0, amount);
                SearchNext(newGroup, id, amount);
            }
        }

    }



    void ButtonStress()
    {
        if (ChangeStress.StressGroups != null)
        {

            // ShowGroupInfo(id);
            int id = int.Parse(ChangeStress.StressGroups)-1;
            Groups[id].groupStress = 0; 
            Groups[id].lessStressed = -1; 
            Groups[id].mostStressed = -1; 
            Groups[id].notStressed = -1; 
           
            //Groups[int.Parse(ChangeStress.StressGroups)].
            for (int i = 0; i < Groups[id].membersAmount; i++)
            {
                int stressPerson = GameObject.Find("Person" + Groups[id].membersId[i]).GetComponent<PersonalData>().stress;

                //����� id � ����������� ��������� ������� � �������
                if (Groups[id].mostStressed == -1 && stressPerson == 1) {
                    Groups[id].mostStressed = i;
                }
                if (Groups[id].lessStressed == -1 && stressPerson == -1)
                {
                    Groups[id].lessStressed = i;
                }
                if (Groups[id].notStressed == -1 && stressPerson == 0)
                {
                    Groups[id].notStressed = i;
                }
              //  Debug.Log(i + "  " + Groups[id].mostStressed+" // "+ Groups[id].lessStressed+ " // not:" + Groups[id].notStressed);
                //   Debug.Log(i+" "+Groups[id].groupStress+"--->"+GameObject.Find("Person" + Groups[id].membersId[i]).GetComponent<PersonalData>().stress);
                Groups[id].groupStress += GameObject.Find("Person" + Groups[id].membersId[i]).GetComponent<PersonalData>().stress;
                //��������� ������� ��������� � ���������� ��������
                
            }
            Groups[id].groupStress = Groups[id].groupStress / Groups[id].membersAmount;
          
        }
    }

    public static void GetStress(int groupId, int mId,int M,int C, int E,int stress,float line) {
        float Z;
       // int status = Groups[groupId].mStatus[0];
        //int status = Groups[groupId].membersId.Find(membersId => membersId == mId);
        int status = Groups[groupId].membersId.IndexOf(mId);
       //  Debug.Log(mId + " // "+status);
        int gR,i;
        int gRs,iss;
        
            if (stress > 0)
            {
                gR = Groups[groupId].lessStressed;
                if (gR == -1) {
                    gR = Groups[groupId].notStressed;
                }
            }
            else
            {
                gR = Groups[groupId].mostStressed;
                if (gR == -1)
                {
                    gR = Groups[groupId].notStressed;
                }
            }
        i = Groups[groupId].membersId[gR];



        int gC = GameObject.Find("Person" + i).GetComponent<BelbinStatus>().C;

         Z = (M * C * status - E * (11 - gR) * gC) * Math.Abs(Groups[groupId].groupStress - stress);
        
         Debug.Log(mId+"  "+stress+ " --->  " + Z);
        if (line <= Z)
        {
            Debug.Log("��������");
        }
        else
        {
            Debug.Log("�������");
        }
        Debug.Log("~~~~~~~~~~~~~~" + "\n");

        // Debug.Log((Groups[groupId].groupStress - stress)+"   "+Z);
        //����� �������� ��� ���������
        //����� ������ �����, ����� ��������� �������, ��������� ������, � ������� ������� �������� (�������� ����)
        //������� Z
        //������� �������� Z, ������� ������ �������� ��� ������
        //���� �� ��. �� ������� ���������� �� ������
        //���� ���,�� ������ �� ����������
    }

}
