using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HideStats : MonoBehaviour
{
    public static bool isHidden = false; //������ �����
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.H))
        {
            isHidden = !isHidden;
            Debug.Log("H");
        }
    }
}
