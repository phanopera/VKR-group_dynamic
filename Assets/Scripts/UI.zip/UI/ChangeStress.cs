using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChangeStress : MonoBehaviour
{
    public Dropdown City;
    public Dropdown Sex;
    public Dropdown Groups;

    public Scrollbar Stress;

    public Transform[] pos;

    public static int StressSt;
//    private bool makeStress;
//    private bool makeHappiness;

    public static string StressCity;
    public static string StressSex;
    public static string StressGroups;
    public static Transform StressGroupsPos;
    // Start is called before the first frame update
    void Start()
    {
        //makeHappiness = false;
       // makeStress = false;
        Stress.value=0.5f;

    }

    // Update is called once per frame
    void Update()
    {
        if (Stress.value < 0.25)
        {
            //makeHappiness = true;
          //  makeStress = false;

            StressSt = -1;
        }
        else if (Stress.value > 0.75)
        {
          // makeHappiness = false;
           // makeStress = true;
            StressSt = 1;
        }
        else
        {
           // makeHappiness = false;
           // makeStress = false;
            StressSt = 0;
        }
    }

    public void ButtonStressCheck() {
        SendStress(City, Sex, Groups, StressSt,pos);
    }

    public static void SendStress(Dropdown city, Dropdown sex, Dropdown group,int stress,Transform[] pos) {
        //if (city.options[city.value].text != "None") {
            StressCity = city.options[city.value].text;
       /* }
        if (sex.options[sex.value].text != "None")
        {*/
            StressSex = sex.options[sex.value].text;
        //}
        if (group.options[group.value].text != "None")
        {
            StressGroups = group.options[group.value].text;
            StressGroupsPos = pos[int.Parse(StressGroups) - 1];
        }
        else {
            StressGroups = null;
        }

        city.value = 0;
        sex.value = 0;
        group.value = 0;
    }
}
