using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BelbinStatus : MonoBehaviour
{
    public enum BelbinType
    { 
        none,
        Strateg, 
        GeneratorIdey, 
        Hozyaistvennik,
        Ekspert,
        DushaKompanii,
        Kritik,
        Peregovorshik,
        Analitik,
        Organizator
    };

    public BelbinType type;

    public int M; //�������������
    public int C; //�������� ������
    public int E; //�������
    public float line; //������� ��� ������ �� ������

    public TextMesh stats;
    public Button myButton;
    // Start is called before the first frame update
    void Start()
    {
        if (type == BelbinType.none)
        {
            MakeStatus();
        }
        if (type == BelbinType.Strateg)
        {
            C =6;
            M =12;
            E =10;
            line = -234;
            stats.text = "M:"+M+" C:"+C+" E:"+E;
        } 
        if (type == BelbinType.GeneratorIdey)
        {
            C =3;
            M =9;
            E =8;
            line = -275.5f;
            stats.text = "M:"+M+" C:"+C+" E:"+E;
        } if (type == BelbinType.Hozyaistvennik)
        {
            C =3;
            M =10;
            E =9;
            line = -312;
            stats.text = "M:"+M+" C:"+C+" E:"+E;
        } if (type == BelbinType.Ekspert)
        {
            C =9;
            M =12;
            E =10;
            line =-36;
            stats.text = "M:"+M+" C:"+C+" E:"+E;
        } if (type == BelbinType.DushaKompanii)
        {
            C =3;
            M =10;
            E =6;
            line =-153;
            stats.text = "M:"+M+" C:"+C+" E:"+E;
        } if (type == BelbinType.Kritik)
        {
            C =6;
            M =10;
            E =8;
            line =-94;
            stats.text = "M:"+M+" C:"+C+" E:"+E;
        } if (type == BelbinType.Peregovorshik)
        {
            C =3;
            M =13;
            E =9;
            line =-397.5f;
            stats.text = "M:"+M+" C:"+C+" E:"+E;
        } if (type == BelbinType.Analitik)
        {
            C =6;
            M =11;
            E =10;
            line =-217;
            stats.text = "M:"+M+" C:"+C+" E:"+E;
        } if (type == BelbinType.Organizator)
        {
            C =4;
            M =10;
            E =8;
            line =-204;
            stats.text = "M:"+M+" C:"+C+" E:"+E;
        }
        myButton = GameObject.Find("ButtonStress").GetComponent<Button>();
        if (myButton != null)
        {
            // ������������� �� ������� ������� ������
            myButton.onClick.AddListener(ButtonStress);
        }
    }



    void Update()
    {
        
        if (HideStats.isHidden)
        {
            stats.text = "";
        }
        else
        {
            stats.text = "M:" + M + " C:" + C + " E:" + E;
        }
    }

    void MakeStatus()
    {
        if (type == BelbinType.none)
        {
            int i = Random.Range(1, 10);
            if (i == 1)
            {
                type = BelbinType.Strateg;
            }
            if (i == 2)
            {
                type = BelbinType.GeneratorIdey;
            }
            if (i == 3)
            {
                type = BelbinType.Hozyaistvennik;
            }
            if (i == 4)
            {
                type = BelbinType.Ekspert;
            }
            if (i == 5)
            {
                type = BelbinType.DushaKompanii;
            }
            if (i == 6)
            {
                type = BelbinType.Kritik;
            }
            if (i == 7)
            {
                type = BelbinType.Peregovorshik;
            }
            if (i == 8)
            {
                type = BelbinType.Analitik;
            }
            if (i == 9)
            {
                type = BelbinType.Organizator;
            }
        }


    }

    void ButtonStress()
    {
       /* float Z;
        //Z=(M*C*(10-1)-E*
        int stressM=GetComponent<PersonalData>().stress;
       // int stressGr= Groups[id].groupStress;*/
      //  Debug.Log("");
    }
}
